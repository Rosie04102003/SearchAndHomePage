package com.example.mentee_searchpage;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private SearchView searchView;
    private RecyclerView recyclerView;
    private List<Item> items;
    private SearchPageAdapterClass myAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.searchPageRecycleView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        searchView = findViewById(R.id.searchPageSearchView);
        searchView.clearFocus();
        items = new ArrayList<>();

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterList(newText);
                return true;
            }
        });


        items.add(new Item("Programming", R.drawable.programming));
        items.add(new Item("Accounting", R.drawable.rectangle));
        items.add(new Item("Films", R.drawable.rectangle));
        items.add(new Item("Recipes", R.drawable.rectangle));
        items.add(new Item("Humanities", R.drawable.rectangle));
        items.add(new Item("Communications", R.drawable.rectangle));
        items.add(new Item("Psychology", R.drawable.rectangle));

        myAdapter = new SearchPageAdapterClass(items);
        recyclerView.setAdapter(myAdapter);
    }

    private void filterList(String text) {
        List<Item> filteredList = new ArrayList<>();
        for (Item item : items){
            if (item.getCourse().toLowerCase().contains(text.toLowerCase())){
                filteredList.add(item);
            }
        }

        if (filteredList.isEmpty()){
            Toast.makeText(this, "No data found", Toast.LENGTH_LONG).show();
        } else {
            myAdapter.setFilteredList(filteredList);
        }
    }
}