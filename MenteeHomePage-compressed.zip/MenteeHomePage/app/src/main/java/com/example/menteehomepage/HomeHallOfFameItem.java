package com.example.menteehomepage;

public class HomeHallOfFameItem {

    String mentorName;
    String mentorCourse;
    String mentorSchool;
    int mentorPicture;

    public HomeHallOfFameItem(String mentorName, String mentorCourse, String mentorSchool, int mentorPicture) {
        this.mentorName = mentorName;
        this.mentorCourse = mentorCourse;
        this.mentorSchool = mentorSchool;
        this.mentorPicture = mentorPicture;
    }

    public String getMentorName() {
        return mentorName;
    }

    public void setMentorName(String mentorName) {
        this.mentorName = mentorName;
    }

    public String getMentorCourse() {
        return mentorCourse;
    }

    public void setMentorCourse(String mentorCourse) {
        this.mentorCourse = mentorCourse;
    }

    public String getMentorSchool() {
        return mentorSchool;
    }

    public void setMentorSchool(String mentorSchool) {
        this.mentorSchool = mentorSchool;
    }

    public int getMentorPicture() {
        return mentorPicture;
    }

    public void setMentorPicture(int mentorPicture) {
        this.mentorPicture = mentorPicture;
    }
}
