package com.example.menteehomepage;

import android.content.ClipData;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class HomeHallOfFameAdapterClass extends RecyclerView.Adapter<HomeHallOfFameViewHolder> {

    private List<HomeHallOfFameItem> items;
    public HomeHallOfFameAdapterClass(List<HomeHallOfFameItem> items) { this.items = items; }

    @NonNull
    @Override
    public HomeHallOfFameViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.home_halloffame_itemview, parent, false);
        return new HomeHallOfFameViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HomeHallOfFameViewHolder holder, int position) {
        holder.mentorPhotoView.setImageResource(items.get(position).getMentorPicture());
        holder.mentorNameView.setText(items.get(position).getMentorName());
        holder.mentorCourseView.setText(items.get(position).getMentorCourse());
        holder.mentorSchoolView.setText(items.get(position).getMentorSchool());
    }

    @Override
    public int getItemCount() {
        return items.size();
    }
}
