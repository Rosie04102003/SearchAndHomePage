package com.example.menteehomepage;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class SuggestionAdapterClass extends RecyclerView.Adapter<SuggestionViewHolder> {

    private List<SuggestionItem> suggestedItems;
    public SuggestionAdapterClass (List<SuggestionItem> suggestedItems) { this.suggestedItems = suggestedItems; }

    @NonNull
    @Override
    public SuggestionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.suggestions_item_view, parent, false);
        return new SuggestionViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SuggestionViewHolder holder, int position) {
        holder.suggestionImageView.setImageResource(suggestedItems.get(position).getSuggestedPhoto());
        holder.suggestionCategoryView.setText(suggestedItems.get(position).getSuggestedCategory());
        holder.suggestionMentorView.setText(suggestedItems.get(position).getSuggestedMentor());
    }

    @Override
    public int getItemCount()  {
        return suggestedItems.size();
    }
}
