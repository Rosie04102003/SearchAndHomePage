package com.example.mentee_searchpage;

public class Item {

    String course;
    int image;

    public Item(String course, int image) {
        this.course = course;
        this.image = image;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}
