package com.example.menteehomepage;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private RecyclerView suggestionRecyclerView;
    private List<HomeHallOfFameItem> items;
    private List<SuggestionItem> suggestionItems;
    private HomeHallOfFameAdapterClass adapter;
    private SuggestionAdapterClass suggestionAdapter;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //hall of fame recyclerview
        recyclerView = findViewById(R.id.HallOfFameRecyclerView);
        items = new ArrayList<>();

        items.add(new HomeHallOfFameItem("Maria Sofia Castro", "BSCS",
                "STI College", R.drawable.rectangle));
        items.add(new HomeHallOfFameItem("Maria Sofia Castro", "BSCS",
                "STI College", R.drawable.rectangle));
        items.add(new HomeHallOfFameItem("Maria Sofia Castro", "BSCS",
                "STI College", R.drawable.rectangle));
        items.add(new HomeHallOfFameItem("Maria Sofia Castro", "BSCS",
                "STI College", R.drawable.rectangle));

        LinearLayoutManager horizontalLayoutManager = new LinearLayoutManager(MainActivity.this, LinearLayoutManager.HORIZONTAL, false);
        //GridLayoutManager gridLayoutManager = new GridLayoutManager(MainActivity.this, 2);
        recyclerView.setLayoutManager(horizontalLayoutManager);

        adapter = new HomeHallOfFameAdapterClass(items);
        recyclerView.setAdapter(adapter);

        //suggestions recyclerview
        suggestionRecyclerView = findViewById(R.id.suggestionRecyclerView);
        suggestionItems = new ArrayList<>();

        suggestionItems.add(new SuggestionItem("Programming",
                "Maria Sofia Castro", R.drawable.rectangle));
        suggestionItems.add(new SuggestionItem("Business",
                "Maria Sofia Castro", R.drawable.rectangle));
        suggestionItems.add(new SuggestionItem("Recipes",
                "Maria Sofia Castro", R.drawable.rectangle));
        suggestionItems.add(new SuggestionItem("Films",
                "Maria Sofia Castro", R.drawable.rectangle));
        suggestionItems.add(new SuggestionItem("Communications",
                "Maria Sofia Castro", R.drawable.rectangle));

        GridLayoutManager gridLayoutManager = new GridLayoutManager(MainActivity.this, 2);
        suggestionRecyclerView.setLayoutManager(gridLayoutManager);

        suggestionAdapter = new SuggestionAdapterClass(suggestionItems);
        suggestionRecyclerView.setAdapter(suggestionAdapter);
    }
}