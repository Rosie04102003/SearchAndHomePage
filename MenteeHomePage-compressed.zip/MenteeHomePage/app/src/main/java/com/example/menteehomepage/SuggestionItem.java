package com.example.menteehomepage;

public class SuggestionItem {

    String suggestedCategory;
    String suggestedMentor;
    int suggestedPhoto;

    public SuggestionItem(String suggestedCategory, String suggestedMentor, int suggestedPhoto) {
        this.suggestedCategory = suggestedCategory;
        this.suggestedMentor = suggestedMentor;
        this.suggestedPhoto = suggestedPhoto;
    }

    public String getSuggestedCategory() {
        return suggestedCategory;
    }

    public void setSuggestedCategory(String suggestedCategory) {
        this.suggestedCategory = suggestedCategory;
    }

    public String getSuggestedMentor() {
        return suggestedMentor;
    }

    public void setSuggestedMentor(String suggestedMentor) {
        this.suggestedMentor = suggestedMentor;
    }

    public int getSuggestedPhoto() {
        return suggestedPhoto;
    }

    public void setSuggestedPhoto(int suggestedPhoto) {
        this.suggestedPhoto = suggestedPhoto;
    }
}
