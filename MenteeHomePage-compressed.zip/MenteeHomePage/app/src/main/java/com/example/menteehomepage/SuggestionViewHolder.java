package com.example.menteehomepage;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class SuggestionViewHolder extends RecyclerView.ViewHolder {
    ImageView suggestionImageView;
    TextView suggestionCategoryView;
    TextView suggestionMentorView;

    public SuggestionViewHolder(@NonNull View itemView) {
        super(itemView);

        suggestionImageView = itemView.findViewById(R.id.suggestion_image);
        suggestionCategoryView = itemView.findViewById(R.id.suggestion_category);
        suggestionMentorView = itemView.findViewById(R.id.suggestion_mentor);
    }
}
