package com.example.menteehomepage;

import android.media.Image;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

public class HomeHallOfFameViewHolder extends RecyclerView.ViewHolder {

    ImageView mentorPhotoView;
    TextView mentorNameView;
    TextView mentorCourseView;
    TextView mentorSchoolView;

    public HomeHallOfFameViewHolder(@NonNull View itemView) {
        super(itemView);

        mentorPhotoView = itemView.findViewById(R.id.imageOfMentor);
        mentorNameView = itemView.findViewById(R.id.nameOfMentor);
        mentorCourseView = itemView.findViewById(R.id.courseOfMentor);
        mentorSchoolView = itemView.findViewById(R.id.schoolOfMentor);
    }
}
